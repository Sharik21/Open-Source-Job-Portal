# Skills API endpoints
