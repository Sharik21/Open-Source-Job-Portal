"""Authentication API endpoints"""
